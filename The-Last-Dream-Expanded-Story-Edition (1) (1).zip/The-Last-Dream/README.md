# THE LAST DREAM — Interactive Fantasy Story

A dark, premium, long-scroll fantasy experience built with plain HTML, CSS, and JavaScript. No build tools or frameworks required.

## Run in VS Code
1. Extract the ZIP.
2. Open the `The-Last-Dream` folder in VS Code.
3. Open `index.html` using the Live Server extension (recommended), or open the file directly in a browser.

## Features
- Original seven-part fantasy narrative with a cinematic opening and closing.
- Procedural animated starfield, layered CSS landscapes, moonlight, fog, glowing portal, magical forest, dream lake, and sleeping citadel.
- Scroll-triggered reveals, reading progress, current chapter indicator, chapter menu, pointer glow, restrained 3D card tilt, click sparks and ripples.
- Branching choice scene with three distinct story routes and route-specific endings.
- Interactive memory cards, listening woods, Keeper dialogue, closing note, and replay/reset flow.
- Responsive layouts, keyboard-friendly controls, no external JS dependencies, and reduced-motion support.

## Notes
- Google Fonts load from Google Fonts when internet is available; fallback fonts are included.
- All illustrations are generated with CSS and the starfield is drawn on canvas, so the project does not rely on external stock-image URLs.
- The choices are session-only; this is a front-end story and does not send data to a server.
- The motion toggle pauses CSS animations and the procedural starfield. The browser/OS reduced-motion setting is respected.


Expanded story edition: adds two long-form narrative scenes, The House of Echoes and The Bridge Between, with animated environments and a clickable memory reveal. Open index.html with Live Server.
